package utnfc.isi.back.paso02_rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Paso02ApiRestBasicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Paso02ApiRestBasicaApplication.class, args);
	}

}
