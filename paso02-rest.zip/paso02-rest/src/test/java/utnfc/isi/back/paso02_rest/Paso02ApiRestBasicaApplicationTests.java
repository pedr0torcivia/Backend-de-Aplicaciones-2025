package utnfc.isi.back.paso02_rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Paso02ApiRestBasicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
